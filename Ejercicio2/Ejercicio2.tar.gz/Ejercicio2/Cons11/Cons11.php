<html>
	<h2>Ranking de clientes de mayor número de comunicaciones realizadas al menor incluyendo información de cantidad de maquinas de cada uno.</h2>
	
	<form name = "" action = "Cons11DB.php" method="get">
		<input type="submit" value="Submit">
	</form>

	
</html>

