<html>
	<head></head>
	<body>
	<h3>Cantidad de Clientes por zona</h3>
	<form action = 'Consulta7BD.php' method = "get">
	<input type = 'Submit'>
	</form>
	
	</body>
</html>