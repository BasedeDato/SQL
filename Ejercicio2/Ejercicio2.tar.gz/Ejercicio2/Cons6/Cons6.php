<html>
	<h2>Listado de Maquinas que estan en todas las zonas.</h2>
	
	<form name = "" action = "Cons6DB.php" method="get">
		<input type="submit" value="Submit">
	</form>

	
</html>