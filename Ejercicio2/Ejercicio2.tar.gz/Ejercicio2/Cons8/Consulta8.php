<html>
	<head></head>
	<body>
	<h1>Cantidad de cada maquina por ciudad ordenado  por ciudades (alfabetico) y maquina de mayor cantidad a menor</h1>
	<form action = "Consulta8DB.php" method = "get">
		
		<input type = 'Submit'>
	</form>
	</body>
</html>